import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';

import '../config/api_config.dart';
import '../models/organization_model.dart';
import '../models/user_model.dart';
import '../models/attendance_model.dart';

class ApiService {
  static const String _keySavedUser = 'saved_user_profile';

  // --- LOCAL USER SESSION MANAGEMENT ---
  static Future<void> saveUserLocally(UserModel user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keySavedUser, jsonEncode(user.toJson()));
  }

  static Future<UserModel?> getSavedUser() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString(_keySavedUser);
    if (jsonString != null && jsonString.isNotEmpty) {
      try {
        final Map<String, dynamic> data = jsonDecode(jsonString);
        return UserModel.fromJson(data);
      } catch (e) {
        return null;
      }
    }
    return null;
  }

  static Future<void> clearUserSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keySavedUser);
  }

  // --- ORGANIZATIONS ---
  static Future<List<OrganizationModel>> getOrganizations() async {
    final url = Uri.parse(ApiConfig.organizationsUrl);
    final response = await http.get(url).timeout(const Duration(seconds: 10));

    if (response.statusCode == 200) {
      final List<dynamic> list = jsonDecode(utf8.decode(response.bodyBytes));
      return list.map((item) => OrganizationModel.fromJson(item)).toList();
    } else {
      throw Exception("Tashkilotlarni yuklashda xatolik: ${response.statusCode}");
    }
  }

  static Future<OrganizationModel> createOrganization(String name) async {
    final url = Uri.parse(ApiConfig.organizationsUrl);
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'name': name}),
    ).timeout(const Duration(seconds: 10));

    if (response.statusCode == 200) {
      return OrganizationModel.fromJson(jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      throw Exception("Tashkilot yaratishda xatolik: ${response.body}");
    }
  }

  // --- REGISTRATION ---
  static Future<UserModel> registerUser({
    required String fullName,
    required int orgId,
    required String photoPath,
  }) async {
    final url = Uri.parse(ApiConfig.registerUrl);
    final request = http.MultipartRequest('POST', url);

    request.fields['full_name'] = fullName;
    request.fields['org_id'] = orgId.toString();

    // Rasm faylini qo'shish
    final file = File(photoPath);
    if (!file.existsSync()) {
      throw Exception("Surat fayli topilmadi!");
    }

    request.files.add(
      await http.MultipartFile.fromPath('photo', photoPath),
    );

    final streamedResponse = await request.send().timeout(const Duration(seconds: 40));
    final response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode == 200) {
      final data = jsonDecode(utf8.decode(response.bodyBytes));
      final user = UserModel.fromJson(data);
      await saveUserLocally(user);
      return user;
    } else {
      String errorMessage = "Ro'yxatdan o'tishda xatolik yuz berdi";
      try {
        final errJson = jsonDecode(utf8.decode(response.bodyBytes));
        if (errJson['detail'] != null) errorMessage = errJson['detail'];
      } catch (_) {}
      throw Exception(errorMessage);
    }
  }

  // --- ATTENDANCE STATUS ---
  static Future<AttendanceStatusModel> getTodayStatus(int userId) async {
    final url = Uri.parse(ApiConfig.todayAttendanceUrl(userId));
    final response = await http.get(url).timeout(const Duration(seconds: 10));

    if (response.statusCode == 200) {
      return AttendanceStatusModel.fromJson(jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      throw Exception("Davomat holatini olishda xatolik: ${response.statusCode}");
    }
  }

  // --- VERIFY ATTENDANCE (GPS + DEEPFACE) ---
  static Future<AttendanceVerifyResult> verifyAttendance({
    required int userId,
    required String action, // 'IN' yoki 'OUT'
    required double latitude,
    required double longitude,
    required String selfiePhotoPath,
  }) async {
    final url = Uri.parse(ApiConfig.verifyAttendanceUrl);
    final request = http.MultipartRequest('POST', url);

    request.fields['user_id'] = userId.toString();
    request.fields['action'] = action;
    request.fields['latitude'] = latitude.toString();
    request.fields['longitude'] = longitude.toString();

    final file = File(selfiePhotoPath);
    if (!file.existsSync()) {
      throw Exception("Selfi surati topilmadi!");
    }

    request.files.add(
      await http.MultipartFile.fromPath('photo', selfiePhotoPath),
    );

    // DeepFace yuz solishtirishi vaqt talab qilishi mumkin, shuning uchun 60 soniya kutish
    final streamedResponse = await request.send().timeout(const Duration(seconds: 60));
    final response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode == 200) {
      final data = jsonDecode(utf8.decode(response.bodyBytes));
      return AttendanceVerifyResult.fromJson(data);
    } else {
      String err = "Verifikatsiyada xatolik yuz berdi (${response.statusCode})";
      try {
        final errJson = jsonDecode(utf8.decode(response.bodyBytes));
        if (errJson['detail'] != null) err = errJson['detail'];
      } catch (_) {}
      return AttendanceVerifyResult(success: false, message: err);
    }
  }

  // --- HR ADMIN: EMPLOYEES ---
  static Future<List<Map<String, dynamic>>> getEmployees(int orgId) async {
    final url = Uri.parse(ApiConfig.employeesUrl(orgId));
    final response = await http.get(url).timeout(const Duration(seconds: 10));

    if (response.statusCode == 200) {
      final List<dynamic> data = jsonDecode(utf8.decode(response.bodyBytes));
      return List<Map<String, dynamic>>.from(data);
    } else {
      throw Exception("Xodimlar ro'yxatini olishda xatolik");
    }
  }

  static Future<bool> deleteEmployee(int employeeId) async {
    final url = Uri.parse(ApiConfig.deleteEmployeeUrl(employeeId));
    final response = await http.delete(url).timeout(const Duration(seconds: 10));

    if (response.statusCode == 200) {
      return true;
    } else {
      throw Exception("Xodimni o'chirishda xatolik");
    }
  }

  // --- HR ADMIN: DOWNLOAD EXCEL REPORT ---
  static Future<String> downloadMonthlyReport({
    required int orgId,
    required String month, // '2026-09'
  }) async {
    final uri = Uri.parse(ApiConfig.reportDownloadUrl).replace(
      queryParameters: {
        'org_id': orgId.toString(),
        'month': month,
      },
    );

    final response = await http.get(uri).timeout(const Duration(seconds: 60));

    if (response.statusCode == 200) {
      final dir = await getApplicationDocumentsDirectory();
      final filePath = '${dir.path}/davomat_hisobot_$month.xlsx';
      final file = File(filePath);
      await file.writeAsBytes(response.bodyBytes);
      return filePath;
    } else {
      String msg = "Hisobotni shakllantirishda xatolik";
      try {
        final err = jsonDecode(utf8.decode(response.bodyBytes));
        if (err['detail'] != null) msg = err['detail'];
      } catch (_) {}
      throw Exception(msg);
    }
  }
}
