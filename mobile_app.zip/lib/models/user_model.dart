class UserModel {
  final int id;
  final int telegramId;
  final String fullName;
  final int orgId;
  final String role; // 'hr_admin' yoki 'worker'
  final String? faceImagePath;
  final String? organizationName;

  UserModel({
    required this.id,
    required this.telegramId,
    required this.fullName,
    required this.orgId,
    required this.role,
    this.faceImagePath,
    this.organizationName,
  });

  bool get isHrAdmin => role == 'hr_admin';

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] as int,
      telegramId: json['telegram_id'] as int,
      fullName: json['full_name'] as String,
      orgId: json['org_id'] as int,
      role: json['role'] as String? ?? 'worker',
      faceImagePath: json['face_image_path'] as String?,
      organizationName: json['organization_name'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'telegram_id': telegramId,
    'full_name': fullName,
    'org_id': orgId,
    'role': role,
    'face_image_path': faceImagePath,
    'organization_name': organizationName,
  };
}
