class AttendanceStatusModel {
  final bool hasCheckedInToday;
  final bool hasCheckedOutToday;
  final DateTime? checkInTime;
  final DateTime? checkOutTime;

  AttendanceStatusModel({
    required this.hasCheckedInToday,
    required this.hasCheckedOutToday,
    this.checkInTime,
    this.checkOutTime,
  });

  factory AttendanceStatusModel.fromJson(Map<String, dynamic> json) {
    return AttendanceStatusModel(
      hasCheckedInToday: json['has_checked_in_today'] as bool? ?? false,
      hasCheckedOutToday: json['has_checked_out_today'] as bool? ?? false,
      checkInTime: json['check_in_time'] != null
          ? DateTime.tryParse(json['check_in_time'])
          : null,
      checkOutTime: json['check_out_time'] != null
          ? DateTime.tryParse(json['check_out_time'])
          : null,
    );
  }
}

class AttendanceVerifyResult {
  final bool success;
  final String message;
  final String? action;
  final DateTime? timestamp;
  final double? similarityScore;
  final int? attendanceId;

  AttendanceVerifyResult({
    required this.success,
    required this.message,
    this.action,
    this.timestamp,
    this.similarityScore,
    this.attendanceId,
  });

  factory AttendanceVerifyResult.fromJson(Map<String, dynamic> json) {
    return AttendanceVerifyResult(
      success: json['success'] as bool? ?? false,
      message: json['message'] as String? ?? '',
      action: json['action'] as String?,
      timestamp: json['timestamp'] != null
          ? DateTime.tryParse(json['timestamp'])
          : null,
      similarityScore: (json['similarity_score'] as num?)?.toDouble(),
      attendanceId: json['attendance_id'] as int?,
    );
  }
}
