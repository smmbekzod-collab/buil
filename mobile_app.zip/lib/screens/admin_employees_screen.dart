import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/api_service.dart';

class AdminEmployeesScreen extends StatefulWidget {
  final UserModel user;

  const AdminEmployeesScreen({Key? key, required this.user}) : super(key: key);

  @override
  State<AdminEmployeesScreen> createState() => _AdminEmployeesScreenState();
}

class _AdminEmployeesScreenState extends State<AdminEmployeesScreen> {
  List<Map<String, dynamic>> _employees = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchEmployees();
  }

  Future<void> _fetchEmployees() async {
    setState(() => _isLoading = true);
    try {
      final list = await ApiService.getEmployees(widget.user.orgId);
      setState(() {
        _employees = list;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Xodimlarni olishda xatolik: $e")),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _confirmDelete(Map<String, dynamic> emp) async {
    final empId = emp['id'] as int;
    final empName = emp['full_name'] as String;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Xodimni o'chirish"),
        content: Text(
          "Haqiqatan ham '$empName' xodimini va uning barcha davomat yozuvlarini bazadan o'chirmoqchimisiz?\n\nBu amalni ortga qaytarib bo'lmaydi.",
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text("Bekor qilish"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text("Ha, o'chirish", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      try {
        await ApiService.deleteEmployee(empId);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("'$empName' tizimdan o'chirildi"),
            backgroundColor: Colors.green,
          ),
        );
        _fetchEmployees();
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("O'chirishda xatolik: $e")),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F8F6),
      appBar: AppBar(
        title: const Text("Xodimlarni Boshqarish"),
        backgroundColor: const Color(0xFF0D5328),
        foregroundColor: Colors.white,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFF0D5328)))
          : _employees.isEmpty
              ? const Center(
                  child: Text(
                    "Tashkilotda boshqa xodimlar topilmadi.",
                    style: TextStyle(color: Colors.black54, fontSize: 15),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _fetchEmployees,
                  color: const Color(0xFF0D5328),
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: _employees.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final emp = _employees[index];
                      final isHr = emp['role'] == 'hr_admin';
                      final totalAtt = emp['total_attendances'] ?? 0;

                      return Card(
                        elevation: 1.5,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        child: Padding(
                          padding: const EdgeInsets.all(14.0),
                          child: Row(
                            children: [
                              CircleAvatar(
                                radius: 24,
                                backgroundColor: isHr ? Colors.amber.shade100 : Colors.green.shade100,
                                child: Icon(
                                  Icons.person,
                                  color: isHr ? Colors.amber.shade900 : const Color(0xFF0D5328),
                                ),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      emp['full_name'] ?? "Noma'lum",
                                      style: const TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Row(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                          decoration: BoxDecoration(
                                            color: isHr ? Colors.amber.shade100 : Colors.grey.shade200,
                                            borderRadius: BorderRadius.circular(8),
                                          ),
                                          child: Text(
                                            isHr ? "HR ADMIN" : "XODIM",
                                            style: TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.bold,
                                              color: isHr ? Colors.amber.shade900 : Colors.black87,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                        Text(
                                          "Davomat: $totalAtt ta",
                                          style: const TextStyle(fontSize: 12, color: Colors.black54),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              // O'chirish tugmasi
                              IconButton(
                                icon: const Icon(Icons.delete_outline, color: Colors.red),
                                tooltip: "Xodimni o'chirish",
                                onPressed: () => _confirmDelete(emp),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
