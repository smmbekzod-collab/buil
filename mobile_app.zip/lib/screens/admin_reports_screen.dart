import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:intl/intl.dart';

import '../models/user_model.dart';
import '../services/api_service.dart';

class AdminReportsScreen extends StatefulWidget {
  final UserModel user;

  const AdminReportsScreen({Key? key, required this.user}) : super(key: key);

  @override
  State<AdminReportsScreen> createState() => _AdminReportsScreenState();
}

class _AdminReportsScreenState extends State<AdminReportsScreen> {
  DateTime _selectedDate = DateTime.now();
  bool _isDownloading = false;
  String? _downloadedFilePath;

  Future<void> _pickMonth() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2024),
      lastDate: DateTime(now.year + 2),
      helpText: "Hisobot oyini tanlang",
    );

    if (picked != null) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _downloadReport() async {
    setState(() {
      _isDownloading = true;
      _downloadedFilePath = null;
    });

    final monthStr = DateFormat('yyyy-MM').format(_selectedDate);

    try {
      final filePath = await ApiService.downloadMonthlyReport(
        orgId: widget.user.orgId,
        month: monthStr,
      );

      setState(() {
        _downloadedFilePath = filePath;
      });

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("✅ Excel hisoboti muvaffaqiyatli yuklab olindi!"),
          backgroundColor: Colors.green,
        ),
      );

      // Faylni avtomatik ochish
      await OpenFilex.open(filePath);
    } catch (e) {
      if (mounted) {
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text("Hisobot yuklashda xatolik"),
            content: Text("$e"),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text("OK"),
              ),
            ],
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isDownloading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final monthDisplay = DateFormat('MMMM yyyy', 'uz').format(_selectedDate);
    final monthCode = DateFormat('yyyy-MM').format(_selectedDate);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Oylik Davomat Hisoboti"),
        backgroundColor: const Color(0xFF0D5328),
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Ma'lumot kartochkasi
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.green.shade200),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info_outline, color: Color(0xFF0D5328), size: 28),
                  SizedBox(width: 14),
                  Expanded(
                    child: Text(
                      "Excel hisobotda xodimlarning kelgan va ketgan vaqtlari, geolokatsiya koordinatalari hamda tasdiqlangan selfi fotosuratlari jamlanadi.",
                      style: TextStyle(color: Color(0xFF0D5328), fontSize: 13, height: 1.4),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Oy tanlash qismi
            const Text(
              "Hisobot oyi:",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            InkWell(
              onTap: _pickMonth,
              borderRadius: BorderRadius.circular(14),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.grey.shade300, width: 1.5),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.calendar_month, color: Color(0xFF0D5328)),
                        const SizedBox(width: 12),
                        Text(
                          monthDisplay,
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        monthCode,
                        style: TextStyle(color: Colors.grey.shade700, fontSize: 13),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 36),

            // Yuklab olish tugmasi
            ElevatedButton.icon(
              onPressed: _isDownloading ? null : _downloadReport,
              icon: _isDownloading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                    )
                  : const Icon(Icons.file_download),
              label: Text(
                _isDownloading ? "Excel fayli tayyorlanmoqda..." : "📊 Excel Hisobotini Yuklab Olish",
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0D5328),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 18),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                elevation: 2,
              ),
            ),

            if (_downloadedFilePath != null) ...[
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.green, width: 1.5),
                ),
                child: Column(
                  children: [
                    const Icon(Icons.check_circle, color: Colors.green, size: 36),
                    const SizedBox(height: 8),
                    const Text(
                      "Fayl qurilmangizga saqlandi!",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: () => OpenFilex.open(_downloadedFilePath!),
                      icon: const Icon(Icons.open_in_new),
                      label: const Text("Faylni Ochish"),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
