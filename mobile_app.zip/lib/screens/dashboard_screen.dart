import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/user_model.dart';
import '../models/attendance_model.dart';
import '../services/api_service.dart';
import 'face_attendance_screen.dart';
import 'admin_reports_screen.dart';
import 'admin_employees_screen.dart';
import 'settings_screen.dart';
import 'register_screen.dart';

class DashboardScreen extends StatefulWidget {
  final UserModel user;

  const DashboardScreen({Key? key, required this.user}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late UserModel _currentUser;
  AttendanceStatusModel? _todayStatus;
  bool _isLoadingStatus = false;

  @override
  void initState() {
    super.initState();
    _currentUser = widget.user;
    _loadTodayStatus();
  }

  Future<void> _loadTodayStatus() async {
    setState(() => _isLoadingStatus = true);
    try {
      final status = await ApiService.getTodayStatus(_currentUser.id);
      setState(() {
        _todayStatus = status;
      });
    } catch (e) {
      debugPrint("Davomat holatini olishda xatolik: $e");
    } finally {
      if (mounted) setState(() => _isLoadingStatus = false);
    }
  }

  void _onAttendanceTap(String action) async {
    // Agar bugun allaqachon belgilangan bo'lsa ogohlantirish
    if (_todayStatus != null) {
      if (action == 'IN' && _todayStatus!.hasCheckedInToday) {
        _showAlreadyMarkedDialog("ishga kelganingizni");
        return;
      }
      if (action == 'OUT' && _todayStatus!.hasCheckedOutToday) {
        _showAlreadyMarkedDialog("ishdan ketganingizni");
        return;
      }
    }

    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => FaceAttendanceScreen(
          user: _currentUser,
          action: action,
        ),
      ),
    );

    if (result == true) {
      _loadTodayStatus();
    }
  }

  void _showAlreadyMarkedDialog(String actionName) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("⚠️ Ogohlantirish"),
        content: Text("Siz bugun allaqachon $actionName qayd etgansiz!"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("Tushunarli"),
          ),
        ],
      ),
    );
  }

  void _logout() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Tizimdan chiqish"),
        content: const Text("Haqiqatan ham hisobdan chiqmoqchimisiz?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text("Yo'q"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text("Ha, chiqish", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await ApiService.clearUserSession();
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const RegisterScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final todayFormatted = DateFormat('dd.MM.yyyy, EEEE', 'uz').format(DateTime.now());
    final isHr = _currentUser.isHrAdmin;

    return Scaffold(
      backgroundColor: const Color(0xFFF6F8F6),
      appBar: AppBar(
        title: const Text("Agrostar Davomat"),
        backgroundColor: const Color(0xFF0D5328),
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: "Yangilash",
            onPressed: _loadTodayStatus,
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: "Server sozlamalari",
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: "Chiqish",
            onPressed: _logout,
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadTodayStatus,
        color: const Color(0xFF0D5328),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. Profil kartochkasi
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF0D5328), Color(0xFF1B8A49)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF0D5328).withOpacity(0.3),
                      blurRadius: 15,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 28,
                          backgroundColor: Colors.white,
                          child: const Icon(Icons.person, color: Color(0xFF0D5328), size: 36),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _currentUser.fullName,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                _currentUser.organizationName ?? "Tashkilot",
                                style: const TextStyle(color: Colors.white70, fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: isHr ? Colors.amber.shade700 : Colors.white24,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            isHr ? "HR ADMIN" : "XODIM",
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const Divider(color: Colors.white24, height: 28),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          "Bugungi sana:",
                          style: TextStyle(color: Colors.white70, fontSize: 13),
                        ),
                        Text(
                          todayFormatted,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // 2. Bugungi davomat holati
              const Text(
                "Bugungi Holat",
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.black87),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _buildStatusCard(
                      title: "Ishga Kelish",
                      time: _todayStatus?.checkInTime != null
                          ? DateFormat('HH:mm').format(_todayStatus!.checkInTime!)
                          : null,
                      isDone: _todayStatus?.hasCheckedInToday ?? false,
                      color: Colors.green,
                      icon: Icons.login,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildStatusCard(
                      title: "Ishdan Ketish",
                      time: _todayStatus?.checkOutTime != null
                          ? DateFormat('HH:mm').format(_todayStatus!.checkOutTime!)
                          : null,
                      isDone: _todayStatus?.hasCheckedOutToday ?? false,
                      color: Colors.redAccent,
                      icon: Icons.logout,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 32),

              // 3. Asosiy Davomat Tugmalari
              const Text(
                "Davomatni Qayd Etish (Face ID + GPS)",
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.black87),
              ),
              const SizedBox(height: 14),

              // ISHGA KELDIM TUGMASI
              _buildActionButton(
                label: "🟢 Ishga Keldim",
                subtitle: "Yuzni tanish va GPS lokatsiyani tasdiqlash",
                color: const Color(0xFF00C853),
                icon: Icons.check_circle_outline,
                isDone: _todayStatus?.hasCheckedInToday ?? false,
                onTap: () => _onAttendanceTap('IN'),
              ),
              const SizedBox(height: 16),

              // ISHDAN KETDIM TUGMASI
              _buildActionButton(
                label: "🔴 Ishdan Ketdim",
                subtitle: "Kunning yakunlanishini qayd etish",
                color: const Color(0xFFD50000),
                icon: Icons.cancel_outlined,
                isDone: _todayStatus?.hasCheckedOutToday ?? false,
                onTap: () => _onAttendanceTap('OUT'),
              ),

              // 4. HR ADMIN BO'LIMI
              if (isHr) ...[
                const SizedBox(height: 36),
                const Row(
                  children: [
                    Icon(Icons.admin_panel_settings, color: Color(0xFF0D5328), size: 22),
                    SizedBox(width: 8),
                    Text(
                      "HR Admin Boshqaruvi",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF0D5328)),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: _buildAdminCard(
                        title: "📊 Oylik Hisobot",
                        subtitle: "Excel (Rasmlar bilan)",
                        icon: Icons.table_view,
                        color: Colors.teal,
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AdminReportsScreen(user: _currentUser),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildAdminCard(
                        title: "🗑️ Xodimlarni o'chirish",
                        subtitle: "Baza va davomat",
                        icon: Icons.group_remove,
                        color: Colors.orange.shade800,
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AdminEmployeesScreen(user: _currentUser),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusCard({
    required String title,
    required String? time,
    required bool isDone,
    required Color color,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDone ? color.withOpacity(0.5) : Colors.grey.shade200,
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: TextStyle(color: Colors.grey.shade700, fontSize: 13, fontWeight: FontWeight.w500),
              ),
              Icon(icon, color: isDone ? color : Colors.grey.shade400, size: 20),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            time ?? "Qayd etilmagan",
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: isDone ? color : Colors.black45,
            ),
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isDone ? color : Colors.grey.shade400,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                isDone ? "Bajarildi" : "Kutilmoqda",
                style: TextStyle(
                  fontSize: 11,
                  color: isDone ? color : Colors.grey.shade600,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton({
    required String label,
    required String subtitle,
    required Color color,
    required IconData icon,
    required bool isDone,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      elevation: 2,
      shadowColor: color.withOpacity(0.15),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: color.withOpacity(0.3),
              width: 1.5,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: color, size: 30),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey.shade900,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                    ),
                  ],
                ),
              ),
              if (isDone)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    "QAYD ETILGAN",
                    style: TextStyle(color: Colors.green, fontSize: 10, fontWeight: FontWeight.bold),
                  ),
                )
              else
                const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.black26),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAdminCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      elevation: 2,
      shadowColor: Colors.black.withOpacity(0.04),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: color, size: 26),
              ),
              const SizedBox(height: 14),
              Text(
                title,
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
