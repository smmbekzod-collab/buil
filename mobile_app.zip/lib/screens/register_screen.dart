import 'dart:io';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:permission_handler/permission_handler.dart';

import '../models/organization_model.dart';
import '../services/api_service.dart';
import 'dashboard_screen.dart';
import 'settings_screen.dart';
import '../widgets/camera_face_overlay.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _fioController = TextEditingController();
  List<OrganizationModel> _organizations = [];
  OrganizationModel? _selectedOrg;
  String? _capturedPhotoPath;
  bool _isLoadingOrgs = false;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _loadOrganizations();
  }

  @override
  void dispose() {
    _fioController.dispose();
    super.dispose();
  }

  Future<void> _loadOrganizations() async {
    setState(() => _isLoadingOrgs = true);
    try {
      final orgs = await ApiService.getOrganizations();
      setState(() {
        _organizations = orgs;
        if (orgs.isNotEmpty) {
          _selectedOrg = orgs.first;
        }
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Tashkilotlarni yuklashda xatolik: $e"),
            backgroundColor: Colors.red,
            action: SnackBarAction(
              label: "Sozlamalar",
              textColor: Colors.white,
              onPressed: () => _openSettings(),
            ),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoadingOrgs = false);
    }
  }

  void _openSettings() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const SettingsScreen()),
    );
    if (result == true) {
      _loadOrganizations();
    }
  }

  Future<void> _showAddOrgDialog() async {
    final nameController = TextEditingController();
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Yangi Tashkilot Qo'shish"),
        content: TextField(
          controller: nameController,
          decoration: const InputDecoration(
            hintText: "Tashkilot nomi (masalan: Agrostar №1)",
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("Bekor qilish"),
          ),
          ElevatedButton(
            onPressed: () async {
              final name = nameController.text.trim();
              if (name.isNotEmpty) {
                Navigator.pop(ctx);
                try {
                  final newOrg = await ApiService.createOrganization(name);
                  setState(() {
                    _organizations.add(newOrg);
                    _selectedOrg = newOrg;
                  });
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("Xatolik: $e")),
                  );
                }
              }
            },
            child: const Text("Qo'shish"),
          ),
        ],
      ),
    );
  }

  Future<void> _takeSelfie() async {
    // Ruxsatlarni tekshirish
    final status = await Permission.camera.request();
    if (status != PermissionStatus.granted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Iltimos, kamera ruxsatini bering")),
        );
      }
      return;
    }

    // Kameralarni topish
    final cameras = await availableCameras();
    CameraDescription? frontCamera;
    for (var cam in cameras) {
      if (cam.lensDirection == CameraLensDirection.front) {
        frontCamera = cam;
        break;
      }
    }
    frontCamera ??= cameras.isNotEmpty ? cameras.first : null;

    if (frontCamera == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Qurilmada kamera topilmadi")),
        );
      }
      return;
    }

    if (!mounted) return;

    final String? photoPath = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _SelfieCaptureScreen(camera: frontCamera!),
      ),
    );

    if (photoPath != null) {
      setState(() {
        _capturedPhotoPath = photoPath;
      });
    }
  }

  Future<void> _submitRegistration() async {
    final fio = _fioController.text.trim();
    if (fio.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Iltimos, to'liq F.I.O. ingizni kiriting")),
      );
      return;
    }

    if (_selectedOrg == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Iltimos, tashkilotni tanlang")),
      );
      return;
    }

    if (_capturedPhotoPath == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Iltimos, old kamera orqali yuzingizni suratga oling")),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      final user = await ApiService.registerUser(
        fullName: fio,
        orgId: _selectedOrg!.id,
        photoPath: _capturedPhotoPath!,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("🎉 Tabriklaymiz! Siz muvaffaqiyatli ro'yxatdan o'tdingiz. Rolingiz: ${user.role.toUpperCase()}"),
          backgroundColor: Colors.green,
        ),
      );

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => DashboardScreen(user: user),
        ),
      );
    } catch (e) {
      if (mounted) {
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text("Ro'yxatdan o'tishda xatolik"),
            content: Text("$e"),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text("OK"),
              ),
            ],
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Ro'yxatdan o'tish"),
        backgroundColor: const Color(0xFF0D5328),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: "Server sozlamalari",
            onPressed: _openSettings,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              "Agrostar Tizimida Ro'yxatdan O'tish",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color(0xFF0D5328),
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              "Ma'lumotlaringizni to'ldiring va shaxsingizni tasdiqlash uchun selfi rasm oling",
              style: TextStyle(color: Colors.black54, fontSize: 13),
            ),
            const SizedBox(height: 24),

            // FIO
            TextField(
              controller: _fioController,
              decoration: InputDecoration(
                labelText: "To'liq F.I.O.",
                hintText: "Masalan: Bozorov Umidbek",
                prefixIcon: const Icon(Icons.person),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 20),

            // Tashkilot tanlash
            Row(
              children: [
                Expanded(
                  child: _isLoadingOrgs
                      ? const Center(child: CircularProgressIndicator())
                      : DropdownButtonFormField<OrganizationModel>(
                          value: _selectedOrg,
                          decoration: InputDecoration(
                            labelText: "Tashkilotni tanlang",
                            prefixIcon: const Icon(Icons.business),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                          items: _organizations.map((org) {
                            return DropdownMenuItem(
                              value: org,
                              child: Text(org.name),
                            );
                          }).toList(),
                          onChanged: (val) => setState(() => _selectedOrg = val),
                        ),
                ),
                const SizedBox(width: 8),
                IconButton.filledTonal(
                  onPressed: _showAddOrgDialog,
                  icon: const Icon(Icons.add_business),
                  tooltip: "Yangi tashkilot qo'shish",
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Selfi rasm olish
            const Text(
              "Yuz etaloni (Face ID)",
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            GestureDetector(
              onTap: _takeSelfie,
              child: Container(
                height: 190,
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: _capturedPhotoPath != null ? const Color(0xFF0D5328) : Colors.grey.shade400,
                    width: _capturedPhotoPath != null ? 2.5 : 1.5,
                  ),
                ),
                child: _capturedPhotoPath != null
                    ? Stack(
                        fit: StackFit.expand,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: Image.file(
                              File(_capturedPhotoPath!),
                              fit: BoxFit.cover,
                            ),
                          ),
                          Positioned(
                            bottom: 8,
                            right: 8,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.7),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.check_circle, color: Colors.greenAccent, size: 16),
                                  SizedBox(width: 4),
                                  Text("Qayta olish", style: TextStyle(color: Colors.white, fontSize: 12)),
                                ],
                              ),
                            ),
                          ),
                        ],
                      )
                    : const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.camera_front, size: 54, color: Color(0xFF0D5328)),
                          SizedBox(height: 10),
                          Text(
                            "Old kameradan Selfi olish",
                            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                          ),
                          SizedBox(height: 4),
                          Text(
                            "Yuzingiz aniq ko'ringan holda rasmga tushing",
                            style: TextStyle(color: Colors.black54, fontSize: 12),
                          ),
                        ],
                      ),
              ),
            ),
            const SizedBox(height: 32),

            // Submit Button
            SizedBox(
              height: 52,
              child: ElevatedButton(
                onPressed: _isSubmitting ? null : _submitRegistration,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF0D5328),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  elevation: 2,
                ),
                child: _isSubmitting
                    ? const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                          ),
                          SizedBox(width: 12),
                          Text("Yuklanmoqda..."),
                        ],
                      )
                    : const Text(
                        "Ro'yxatdan O'tish",
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SelfieCaptureScreen extends StatefulWidget {
  final CameraDescription camera;

  const _SelfieCaptureScreen({Key? key, required this.camera}) : super(key: key);

  @override
  State<_SelfieCaptureScreen> createState() => _SelfieCaptureScreenState();
}

class _SelfieCaptureScreenState extends State<_SelfieCaptureScreen> {
  late CameraController _controller;
  late Future<void> _initializeControllerFuture;
  bool _isTaking = false;

  @override
  void initState() {
    super.initState();
    _controller = CameraController(
      widget.camera,
      ResolutionPreset.medium,
      enableAudio: false,
    );
    _initializeControllerFuture = _controller.initialize();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _capture() async {
    if (_isTaking) return;
    setState(() => _isTaking = true);
    try {
      await _initializeControllerFuture;
      final image = await _controller.takePicture();
      if (!mounted) return;
      Navigator.pop(context, image.path);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Suratga olishda xatolik: $e")),
      );
    } finally {
      if (mounted) setState(() => _isTaking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: FutureBuilder<void>(
        future: _initializeControllerFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return Stack(
              fit: StackFit.expand,
              children: [
                CameraPreview(_controller),
                const CameraFaceOverlay(
                  title: "Yuz etaloni uchun selfi oling",
                  subtitle: "Yuzingizni markazdagi oval ichiga joylashtiring",
                ),
                Positioned(
                  bottom: 36,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: GestureDetector(
                      onTap: _capture,
                      child: Container(
                        width: 78,
                        height: 78,
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 4),
                        ),
                        child: Container(
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white,
                          ),
                          child: _isTaking
                              ? const CircularProgressIndicator(color: Color(0xFF0D5328))
                              : const Icon(Icons.camera_alt, color: Color(0xFF0D5328), size: 36),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          } else {
            return const Center(child: CircularProgressIndicator(color: Colors.white));
          }
        },
      ),
    );
  }
}
