import 'dart:io';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

import '../models/user_model.dart';
import '../services/api_service.dart';
import '../widgets/camera_face_overlay.dart';

class FaceAttendanceScreen extends StatefulWidget {
  final UserModel user;
  final String action; // 'IN' yoki 'OUT'

  const FaceAttendanceScreen({
    Key? key,
    required this.user,
    required this.action,
  }) : super(key: key);

  @override
  State<FaceAttendanceScreen> createState() => _FaceAttendanceScreenState();
}

class _FaceAttendanceScreenState extends State<FaceAttendanceScreen> {
  CameraController? _cameraController;
  Future<void>? _initializeControllerFuture;
  Position? _currentPosition;
  String _gpsStatusText = "GPS koordinatalar aniqlanmoqda...";
  bool _isGpsReady = false;
  bool _isVerifying = false;

  @override
  void initState() {
    super.initState();
    _initCameraAndGps();
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    super.dispose();
  }

  Future<void> _initCameraAndGps() async {
    // 1. Kamera va Lokatsiya ruxsatlarini so'rash
    final cameraStatus = await Permission.camera.request();
    final locationStatus = await Permission.location.request();

    if (cameraStatus != PermissionStatus.granted) {
      if (mounted) {
        _showErrorDialog("Kamera ruxsati berilmadi. Davomat uchun kamera shart!");
      }
      return;
    }

    // 2. Kameralarni initsializatsiya qilish (Old kamera)
    try {
      final cameras = await availableCameras();
      CameraDescription? frontCamera;
      for (var cam in cameras) {
        if (cam.lensDirection == CameraLensDirection.front) {
          frontCamera = cam;
          break;
        }
      }
      frontCamera ??= cameras.isNotEmpty ? cameras.first : null;

      if (frontCamera != null) {
        _cameraController = CameraController(
          frontCamera,
          ResolutionPreset.medium,
          enableAudio: false,
        );
        setState(() {
          _initializeControllerFuture = _cameraController!.initialize();
        });
      }
    } catch (e) {
      debugPrint("Kamera ochishda xatolik: $e");
    }

    // 3. GPS lokatsiyani olish
    _fetchGpsLocation();
  }

  Future<void> _fetchGpsLocation() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        setState(() {
          _gpsStatusText = "⚠️ Qurilmada GPS o'chirilgan! Iltimos, yoqing.";
          _isGpsReady = false;
        });
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          setState(() {
            _gpsStatusText = "⚠️ Lokatsiya ruxsati berilmadi.";
            _isGpsReady = false;
          });
          return;
        }
      }

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 15),
      );

      if (mounted) {
        setState(() {
          _currentPosition = pos;
          _isGpsReady = true;
          _gpsStatusText = "📍 GPS: ${pos.latitude.toStringAsFixed(5)}, ${pos.longitude.toStringAsFixed(5)} (Aniqlik: ${pos.accuracy.toStringAsFixed(0)}m)";
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _gpsStatusText = "Lokatsiyani olishda xatolik: $e";
          _isGpsReady = false;
        });
      }
    }
  }

  Future<void> _captureAndVerify() async {
    if (_cameraController == null || !_cameraController!.value.isInitialized) {
      return;
    }

    if (!_isGpsReady || _currentPosition == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Iltimos, GPS koordinatalari aniqlanishini kuting"),
          backgroundColor: Colors.orange,
        ),
      );
      _fetchGpsLocation();
      return;
    }

    setState(() => _isVerifying = true);

    try {
      // 1. Rasmga olish
      final image = await _cameraController!.takePicture();

      if (!mounted) return;

      // 2. Serverga yuborish va DeepFace orqali tekshirish
      final result = await ApiService.verifyAttendance(
        userId: widget.user.id,
        action: widget.action,
        latitude: _currentPosition!.latitude,
        longitude: _currentPosition!.longitude,
        selfiePhotoPath: image.path,
      );

      if (!mounted) return;

      // Rasmni vaqtinchalik xotiradan tozalash
      try {
        File(image.path).deleteSync();
      } catch (_) {}

      if (result.success) {
        // MUVAFFAQIYATLI
        await showDialog(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: const Row(
              children: [
                Icon(Icons.check_circle, color: Color(0xFF00C853), size: 30),
                SizedBox(width: 10),
                Text("Tasdiqlandi!"),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  result.message,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 12),
                if (result.similarityScore != null)
                  Text(
                    "AI Yuz mosligi: ${(result.similarityScore! * 100).toStringAsFixed(1)}%",
                    style: const TextStyle(color: Colors.black54, fontSize: 13),
                  ),
                const SizedBox(height: 6),
                Text(
                  "Lokatsiya: ${_currentPosition!.latitude.toStringAsFixed(4)}, ${_currentPosition!.longitude.toStringAsFixed(4)}",
                  style: const TextStyle(color: Colors.black54, fontSize: 13),
                ),
              ],
            ),
            actions: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF0D5328),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: () {
                  Navigator.pop(ctx);
                  Navigator.pop(context, true); // Dashboardga qaytish va yangilash
                },
                child: const Text("Ajoyib, Rahmat!"),
              ),
            ],
          ),
        );
      } else {
        // XATOLIK YOKI YUZ MOS KELMADI
        await showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: const Row(
              children: [
                Icon(Icons.error_outline, color: Colors.red, size: 30),
                SizedBox(width: 10),
                Text("Rad etildi"),
              ],
            ),
            content: Text(
              result.message,
              style: const TextStyle(fontSize: 15),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text("Qayta urinish"),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        _showErrorDialog("Xatolik: $e");
      }
    } finally {
      if (mounted) setState(() => _isVerifying = false);
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Xatolik"),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final actionName = widget.action == 'IN' ? "🟢 Ishga Kelish" : "🔴 Ishdan Ketish";
    final actionColor = widget.action == 'IN' ? const Color(0xFF00C853) : const Color(0xFFD50000);

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(actionName),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.my_location),
            tooltip: "GPS ni yangilash",
            onPressed: _fetchGpsLocation,
          ),
        ],
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // 1. Kamera ko'rinishi
          if (_initializeControllerFuture != null)
            FutureBuilder<void>(
              future: _initializeControllerFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.done && _cameraController != null) {
                  return CameraPreview(_cameraController!);
                } else {
                  return const Center(child: CircularProgressIndicator(color: Colors.white));
                }
              },
            )
          else
            const Center(child: CircularProgressIndicator(color: Colors.white)),

          // 2. Oval yuz ramkasi
          CameraFaceOverlay(
            title: "Yuzingizni doira ichiga to'g'rilang",
            subtitle: widget.action == 'IN'
                ? "Ishga kelganingizni tasdiqlash uchun selfi oling"
                : "Ishdan ketganingizni tasdiqlash uchun selfi oling",
          ),

          // 3. GPS Ma'lumot paneli (tepada)
          Positioned(
            top: 90,
            left: 20,
            right: 20,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: _isGpsReady ? Colors.black.withOpacity(0.75) : Colors.orange.shade900.withOpacity(0.85),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: _isGpsReady ? Colors.greenAccent.withOpacity(0.6) : Colors.amber,
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    _isGpsReady ? Icons.location_on : Icons.location_searching,
                    color: _isGpsReady ? Colors.greenAccent : Colors.white,
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _gpsStatusText,
                      style: const TextStyle(color: Colors.white, fontSize: 12),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // 4. Pastki Suratga Olish Tugmasi
          Positioned(
            bottom: 36,
            left: 24,
            right: 24,
            child: Column(
              children: [
                if (_isVerifying)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.85),
                      borderRadius: BorderRadius.circular(25),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(color: Colors.greenAccent, strokeWidth: 2),
                        ),
                        SizedBox(width: 12),
                        Text(
                          "AI Yuz va GPS tekshirilmoqda...",
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  )
                else
                  GestureDetector(
                    onTap: _captureAndVerify,
                    child: Container(
                      width: 82,
                      height: 82,
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: actionColor, width: 4),
                        boxShadow: [
                          BoxShadow(
                            color: actionColor.withOpacity(0.5),
                            blurRadius: 20,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: actionColor,
                        ),
                        child: const Icon(
                          Icons.camera_alt,
                          color: Colors.white,
                          size: 38,
                        ),
                      ),
                    ),
                  ),
                const SizedBox(height: 10),
                const Text(
                  "Tugmani bosing va qimirlamang",
                  style: TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
