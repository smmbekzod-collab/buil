import 'package:flutter/material.dart';

class CameraFaceOverlay extends StatelessWidget {
  final String title;
  final String subtitle;

  const CameraFaceOverlay({
    Key? key,
    this.title = "Yuzingizni doira ichiga joylashtiring",
    this.subtitle = "Ko'zoynakni yeching va to'g'ri qarang",
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final ovalWidth = size.width * 0.72;
    final ovalHeight = ovalWidth * 1.35;

    return Stack(
      children: [
        // Qorong'i fon bilan o'rtadagi oval teshik
        ColorFiltered(
          colorFilter: ColorFilter.mode(
            Colors.black.withOpacity(0.65),
            BlendMode.srcOut,
          ),
          child: Stack(
            children: [
              Container(
                decoration: const BoxDecoration(
                  color: Colors.transparent,
                  backgroundBlendMode: BlendMode.dstOut,
                ),
              ),
              Align(
                alignment: const Alignment(0, -0.2),
                child: Container(
                  width: ovalWidth,
                  height: ovalHeight,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(
                      Radius.elliptical(ovalWidth / 2, ovalHeight / 2),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        // Oval chegara hoshiyasi (Yashil/Oltin chiziq)
        Align(
          alignment: const Alignment(0, -0.2),
          child: Container(
            width: ovalWidth,
            height: ovalHeight,
            decoration: BoxDecoration(
              border: Border.all(
                color: const Color(0xFF00C853), // Yashil yorug'lik
                width: 3.5,
              ),
              borderRadius: BorderRadius.all(
                Radius.elliptical(ovalWidth / 2, ovalHeight / 2),
              ),
            ),
          ),
        ),
        // Ko'rsatma matni
        Align(
          alignment: Alignment.topCenter,
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(top: 20, left: 24, right: 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      children: [
                        Text(
                          title,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          subtitle,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
