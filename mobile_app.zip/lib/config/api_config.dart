import 'package:shared_preferences/shared_preferences.dart';

class ApiConfig {
  static const String _keyBaseUrl = 'api_base_url';
  
  // Default URL: Android emulyatori uchun 10.0.2.2 yoki lokal tarmoq IP
  static String defaultBaseUrl = 'http://10.0.2.2:8000';
  static String _currentBaseUrl = defaultBaseUrl;

  static String get baseUrl => _currentBaseUrl;

  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _currentBaseUrl = prefs.getString(_keyBaseUrl) ?? defaultBaseUrl;
  }

  static Future<void> setBaseUrl(String newUrl) async {
    // Oxiridagi sleshni olib tashlash
    String cleanUrl = newUrl.trim();
    if (cleanUrl.endsWith('/')) {
      cleanUrl = cleanUrl.substring(0, cleanUrl.length - 1);
    }
    _currentBaseUrl = cleanUrl;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyBaseUrl, _currentBaseUrl);
  }

  // API Endpoints
  static String get organizationsUrl => '$_currentBaseUrl/api/auth/organizations';
  static String get registerUrl => '$_currentBaseUrl/api/auth/register';
  static String userProfileUrl(int id) => '$_currentBaseUrl/api/auth/user/$id';
  static String todayAttendanceUrl(int id) => '$_currentBaseUrl/api/attendance/today/$id';
  static String get verifyAttendanceUrl => '$_currentBaseUrl/api/attendance/verify';
  static String get reportDownloadUrl => '$_currentBaseUrl/api/admin/report';
  static String employeesUrl(int orgId) => '$_currentBaseUrl/api/admin/employees/$orgId';
  static String deleteEmployeeUrl(int id) => '$_currentBaseUrl/api/admin/employees/$id';
}
