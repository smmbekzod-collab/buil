package com.agrostar.attendance

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
